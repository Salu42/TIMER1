import { useState, useEffect } from "react";
import { Volume2, VolumeX, Languages, Timer as TimerIcon, Hourglass, HelpCircle, Keyboard } from "lucide-react";
import Stopwatch from "./components/Stopwatch";
import CountdownTimer from "./components/CountdownTimer";
import { translations } from "./utils/translations";
import { initializeAudio, playClickSound } from "./utils/audio";

export default function App() {
  const [activeTab, setActiveTab] = useState<"stopwatch" | "timer">("stopwatch");
  const [lang, setLang] = useState<"en" | "hi">("en");
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);
  const [showShortcuts, setShowShortcuts] = useState<boolean>(false);

  // Initialize Audio Context on general user touch/click/key interaction
  useEffect(() => {
    const handleGesture = () => {
      initializeAudio();
    };
    
    window.addEventListener("click", handleGesture);
    window.addEventListener("keydown", handleGesture);
    window.addEventListener("touchstart", handleGesture);

    return () => {
      window.removeEventListener("click", handleGesture);
      window.removeEventListener("keydown", handleGesture);
      window.removeEventListener("touchstart", handleGesture);
    };
  }, []);

  const toggleLanguage = () => {
    const nextLang = lang === "en" ? "hi" : "en";
    if (soundEnabled) playClickSound(1200, 0.03);
    setLang(nextLang);
  };

  const toggleSound = () => {
    // Flip sound
    const nextSound = !soundEnabled;
    setSoundEnabled(nextSound);
    if (nextSound) {
      // Trigger a subtle click sound to confirm it is enabled
      setTimeout(() => playClickSound(1000, 0.04), 50);
    }
  };

  const handleTabChange = (tab: "stopwatch" | "timer") => {
    if (soundEnabled) playClickSound(900, 0.04);
    setActiveTab(tab);
  };

  const t = translations[lang];

  return (
    <div className="min-h-screen bg-slate-50/50 flex flex-col justify-between py-6 px-4" id="app-root-container">
      {/* Top Navigation & Configuration Utility Bar */}
      <header className="w-full max-w-xl mx-auto flex items-center justify-between" id="app-header">
        {/* Subtle, Minimalist Logo */}
        <div className="flex items-center gap-2" id="app-logo">
          <div className="w-8 h-8 rounded-xl bg-neutral-950 flex items-center justify-center text-white font-bold" id="logo-badge">
            C
          </div>
          <div className="flex flex-col" id="logo-text">
            <h1 className="font-display font-medium text-sm tracking-tight text-neutral-800" id="main-title">
              {t.title}
            </h1>
            <span className="text-[10px] text-neutral-400 font-mono tracking-wider uppercase" id="tagline">
              v1.0.0 • offline-ready
            </span>
          </div>
        </div>

        {/* Floating Utility Controls (Mute & Lang Switch) */}
        <div className="flex items-center gap-1.5" id="header-utilities">
          {/* Audio Feedback Toggle */}
          <button
            onClick={toggleSound}
            className={`w-9 h-9 rounded-lg border flex items-center justify-center transition-all cursor-pointer ${
              soundEnabled
                ? "bg-white border-neutral-200 text-neutral-600 hover:bg-neutral-50"
                : "bg-red-50 border-red-100 text-red-500 hover:bg-red-100/50"
            }`}
            title={soundEnabled ? t.soundOff : t.soundOn}
            id="btn-sound-toggle"
          >
            {soundEnabled ? <Volume2 size={16} /> : <VolumeX size={16} />}
          </button>

          {/* Bilingual Switcher */}
          <button
            onClick={toggleLanguage}
            className="h-9 px-2.5 rounded-lg border border-neutral-200 bg-white text-neutral-600 hover:bg-neutral-50 flex items-center gap-1.5 text-xs font-medium cursor-pointer transition-colors"
            title="भाषा बदलें / Switch language"
            id="btn-lang-toggle"
          >
            <Languages size={15} className="text-neutral-400" />
            <span className="font-display">{lang === "en" ? "हिन्दी" : "Eng"}</span>
          </button>

          {/* Shortcut guide visibility toggle */}
          <button
            onClick={() => {
              if (soundEnabled) playClickSound(1000, 0.03);
              setShowShortcuts(!showShortcuts);
            }}
            className={`w-9 h-9 rounded-lg border flex items-center justify-center transition-all cursor-pointer ${
              showShortcuts
                ? "bg-neutral-950 border-neutral-950 text-white"
                : "bg-white border-neutral-200 text-neutral-600 hover:bg-neutral-50"
            }`}
            title={t.keyboardShortcuts}
            id="btn-shortcuts-toggle"
          >
            <Keyboard size={16} />
          </button>
        </div>
      </header>

      {/* Primary Application Stage */}
      <main className="flex-1 flex flex-col items-center justify-center my-6 md:my-8" id="app-main-stage">
        {/* Core Mode Switcher Selector Card */}
        <div className="w-full max-w-sm bg-neutral-100/80 p-1 rounded-2xl border border-neutral-200/50 flex items-center mb-6" id="mode-tab-bar">
          {/* Stopwatch tab pill */}
          <button
            onClick={() => handleTabChange("stopwatch")}
            className={`flex-1 py-2.5 px-4 rounded-xl font-display font-medium text-xs tracking-tight flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
              activeTab === "stopwatch"
                ? "bg-white text-neutral-900 shadow-xs font-semibold"
                : "text-neutral-500 hover:text-neutral-800"
            }`}
            id="tab-stopwatch"
          >
            <TimerIcon size={14} className={activeTab === "stopwatch" ? "text-neutral-800" : "text-neutral-400"} />
            {t.stopwatch}
          </button>

          {/* Timer tab pill */}
          <button
            onClick={() => handleTabChange("timer")}
            className={`flex-1 py-2.5 px-4 rounded-xl font-display font-medium text-xs tracking-tight flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
              activeTab === "timer"
                ? "bg-white text-neutral-900 shadow-xs font-semibold"
                : "text-neutral-500 hover:text-neutral-800"
            }`}
            id="tab-timer"
          >
            <Hourglass size={14} className={activeTab === "timer" ? "text-neutral-800" : "text-neutral-400"} />
            {t.timer}
          </button>
        </div>

        {/* Current Widget viewport container */}
        <div className="w-full max-w-xl transition-all duration-300" id="active-widget-view">
          {activeTab === "stopwatch" ? (
            <Stopwatch t={t} soundEnabled={soundEnabled} />
          ) : (
            <CountdownTimer t={t} soundEnabled={soundEnabled} />
          )}
        </div>
      </main>

      {/* Footer Area with contextual guides */}
      <footer className="w-full max-w-xl mx-auto flex flex-col items-center text-center gap-4 border-t border-neutral-200/40 pt-4" id="app-footer">
        {/* Animated Dropdown Shortcuts menu if enabled */}
        {showShortcuts && (
          <div className="w-full bg-white border border-neutral-200/80 rounded-xl p-3 shadow-xs text-left animate-fade-in" id="shortcuts-info-box">
            <span className="block text-[11px] font-display font-semibold text-neutral-500 uppercase tracking-wider mb-2">
              ⌨️ {t.keyboardShortcuts}
            </span>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 font-mono text-[10px] text-neutral-500" id="shortcuts-grid">
              <div className="bg-neutral-50 rounded p-1.5 border border-neutral-100" id="shortcut-space">
                {t.spaceShortcut}
              </div>
              <div className="bg-neutral-50 rounded p-1.5 border border-neutral-100" id="shortcut-lap">
                {t.lapShortcut}
              </div>
              <div className="bg-neutral-50 rounded p-1.5 border border-neutral-100" id="shortcut-reset">
                {t.resetShortcut}
              </div>
            </div>
          </div>
        )}

        {/* Pure & Humble Credits / Subtitles */}
        <p className="text-xs text-neutral-400 font-sans leading-relaxed tracking-normal max-w-md px-4" id="credit-byline">
          {t.subtitle}
        </p>

        {/* Soft, beautiful, minimal indicator */}
        <div className="flex items-center gap-1 px-3 py-1 bg-white border border-neutral-200 rounded-full text-[10px] font-mono text-neutral-400 font-medium" id="tactile-indicator">
          <span>{lang === "en" ? "ENG" : "हिन्दी"}</span>
          <span className="text-neutral-200">•</span>
          <span>{soundEnabled ? "AUDIO ON" : "MUTED"}</span>
        </div>
      </footer>
    </div>
  );
}
