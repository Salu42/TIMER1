import { useState, useEffect, useRef } from "react";
import { Play, Pause, RotateCcw, Flag, Trash2, Award } from "lucide-react";
import { playClickSound } from "../utils/audio";
import { LocalizedStrings } from "../utils/translations";

interface StopwatchProps {
  t: LocalizedStrings;
  soundEnabled: boolean;
}

interface Lap {
  index: number;
  durationMs: number;
  absoluteMs: number;
}

export default function Stopwatch({ t, soundEnabled }: StopwatchProps) {
  const [isRunning, setIsRunning] = useState(false);
  const [time, setTime] = useState(0); // in Milliseconds
  const [laps, setLaps] = useState<Lap[]>([]);

  // References to keep track of exact high-precision time
  const startTimeRef = useRef<number>(0);
  const elapsedRef = useRef<number>(0);
  const frameRef = useRef<number | null>(null);

  // Load state from localStorage on mount
  useEffect(() => {
    try {
      const storedData = localStorage.getItem("chrono_stopwatch");
      if (storedData) {
        const parsed = JSON.parse(storedData);
        // We only restore state if it was paused to avoid weird clock jumps
        if (parsed.time) setTime(parsed.time);
        if (parsed.laps) setLaps(parsed.laps);
        elapsedRef.current = parsed.time || 0;
      }
    } catch (e) {
      console.warn("Could not load stopwatch state:", e);
    }
  }, []);

  // Save changes to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(
        "chrono_stopwatch",
        JSON.stringify({
          time,
          laps,
        })
      );
    } catch (e) {
      console.warn("Could not save stopwatch state:", e);
    }
  }, [time, laps]);

  // RequestAnimationFrame tick for ultra precision & high performance
  const tick = () => {
    const elapsed = Date.now() - startTimeRef.current + elapsedRef.current;
    setTime(elapsed);
    frameRef.current = requestAnimationFrame(tick);
  };

  const handleStartStop = () => {
    if (soundEnabled) playClickSound(1000, 0.04);
    
    if (isRunning) {
      // Pause
      if (frameRef.current) cancelAnimationFrame(frameRef.current);
      elapsedRef.current = Date.now() - startTimeRef.current + elapsedRef.current;
      setTime(elapsedRef.current);
      setIsRunning(false);
    } else {
      // Start/Resume
      startTimeRef.current = Date.now();
      setIsRunning(true);
      frameRef.current = requestAnimationFrame(tick);
    }
  };

  const handleReset = () => {
    if (soundEnabled) playClickSound(600, 0.06);
    if (frameRef.current) cancelAnimationFrame(frameRef.current);
    setIsRunning(false);
    elapsedRef.current = 0;
    setTime(0);
    setLaps([]);
    try {
      localStorage.removeItem("chrono_stopwatch");
    } catch (_) {}
  };

  const handleLap = () => {
    if (!isRunning) return;
    if (soundEnabled) playClickSound(1200, 0.05);

    const currentTotal = Date.now() - startTimeRef.current + elapsedRef.current;
    const lastLapAbsolute = laps.length > 0 ? laps[0].absoluteMs : 0;
    const lapDuration = currentTotal - lastLapAbsolute;

    const newLap: Lap = {
      index: laps.length + 1,
      durationMs: lapDuration,
      absoluteMs: currentTotal,
    };

    // Unshift to put latest lap at the top of the table
    setLaps([newLap, ...laps]);
  };

  const handleClearLapsOnDemand = () => {
    if (soundEnabled) playClickSound(400, 0.08);
    setLaps([]);
  };

  // Cleanup anim frame on unmount
  useEffect(() => {
    return () => {
      if (frameRef.current) cancelAnimationFrame(frameRef.current);
    };
  }, []);

  // Keyboard shortcut listener
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Avoid firing hotkeys when user is focused inside input elements (none inside stopwatch, but safe practice)
      if (document.activeElement?.tagName === "INPUT" || document.activeElement?.tagName === "TEXTAREA") {
        return;
      }

      if (e.code === "Space") {
        e.preventDefault();
        handleStartStop();
      } else if (e.code === "KeyR") {
        e.preventDefault();
        handleReset();
      } else if (e.code === "KeyL") {
        e.preventDefault();
        handleLap();
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [isRunning, laps, soundEnabled]);

  // Formatter utility for display
  const formatTimeParts = (totalMs: number) => {
    const ms = Math.floor((totalMs % 1000) / 10);
    const totalSecs = Math.floor(totalMs / 1000);
    const secs = totalSecs % 60;
    const mins = Math.floor(totalSecs / 60) % 60;
    const hours = Math.floor(totalSecs / 3600);

    const pad = (n: number) => n.toString().padStart(2, "0");
    const padMs = (n: number) => n.toString().padStart(2, "0");

    return {
      hours: pad(hours),
      minutes: pad(mins),
      seconds: pad(secs),
      ms: padMs(ms),
    };
  };

  const { hours, minutes, seconds, ms } = formatTimeParts(time);

  // Computations for fastest/slowest lap
  // We need at least 2 laps to highlight the speeds
  let fastestLapId = -1;
  let slowestLapId = -1;
  let averageLapMs = 0;

  if (laps.length > 0) {
    const calculatedLaps = [...laps];
    let minDur = Infinity;
    let maxDur = -Infinity;
    let totalDur = 0;

    calculatedLaps.forEach((l) => {
      totalDur += l.durationMs;
      if (l.durationMs < minDur) minDur = l.durationMs;
      if (l.durationMs > maxDur) maxDur = l.durationMs;
    });

    averageLapMs = Math.round(totalDur / laps.length);

    if (laps.length >= 2) {
      laps.forEach((l) => {
        if (l.durationMs === minDur && fastestLapId === -1) fastestLapId = l.index;
        if (l.durationMs === maxDur && slowestLapId === -1) slowestLapId = l.index;
      });
    }
  }

  const formatLapDuration = (durMs: number) => {
    const totalSecs = Math.floor(durMs / 1000);
    const centis = Math.floor((durMs % 1000) / 10);
    const secs = totalSecs % 60;
    const mins = Math.floor(totalSecs / 60) % 60;
    
    const pad = (n: number) => n.toString().padStart(2, "0");
    return `${pad(mins)}:${pad(secs)}.${pad(centis)}`;
  };

  return (
    <div className="flex flex-col items-center justify-center p-2 sm:p-4 w-full max-w-xl mx-auto" id="stopwatch-container">
      {/* Decorative Rotating Border Graphic */}
      <div className="relative flex items-center justify-center w-64 h-64 sm:w-72 sm:h-72 rounded-full border border-neutral-200/80 bg-white shadow-xs mb-8" id="stopwatch-ring-outer">
        {/* Animated Accent Pulsar */}
        <div 
          className={`absolute inset-3 rounded-full border-2 border-dashed border-neutral-300 transition-transform duration-1000 ease-linear ${isRunning ? "animate-[spin_40s_linear_infinite]" : ""}`}
          id="dashed-ring-animation"
        />

        {/* Micro-scale millisecond rotation indicator */}
        <div 
          className="absolute inset-[10px] rounded-full border border-neutral-100 bg-linear-to-b from-neutral-50/20 to-white"
          id="inner-dial-background"
        />

        {/* Primary Clock display centered with customized size */}
        <div className="z-10 flex flex-col items-center justify-center text-center" id="dial-clock-display">
          <span className="text-xs uppercase tracking-widest text-neutral-400 font-display font-semibold mb-1" id="stopwatch-label">
            {t.stopwatch}
          </span>
          
          <div className="flex items-baseline justify-center font-mono text-neutral-800" id="digits-grid">
            <span className="text-4xl sm:text-5xl font-bold tracking-tight" id="hours-minutes-seconds-digits">
              {hours !== "00" && `${hours}:`}{minutes}:{seconds}
            </span>
            <span className="text-xl sm:text-2xl font-medium text-neutral-400 ml-1" id="millis-digits">
              .{ms}
            </span>
          </div>

          {/* Inline Active State Text */}
          <div className="min-h-[1.5rem]" id="telemetry-bar">
            {isRunning ? (
              <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[10px] font-mono font-medium text-emerald-600 bg-emerald-50 animate-pulse" id="state-active">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                ACTIVE
              </span>
            ) : time > 0 ? (
              <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[10px] font-mono font-medium text-amber-600 bg-amber-50" id="state-paused">
                <span className="w-1.5 h-1.5 rounded-full bg-amber-400"></span>
                PAUSED
              </span>
            ) : (
              <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[10px] font-mono font-medium text-neutral-400 bg-neutral-100" id="state-ready">
                READY
              </span>
            )}
          </div>
        </div>
      </div>

      {/* Primary Action Buttons */}
      <div className="flex items-center justify-center gap-4 w-full mb-8" id="stopwatch-buttons-panel">
        {/* Reset Button */}
        <button
          onClick={handleReset}
          disabled={time === 0}
          className={`group flex items-center justify-center w-12 h-12 rounded-full border border-neutral-200 bg-white text-neutral-500 hover:text-neutral-800 hover:bg-neutral-50 active:bg-neutral-100 hover:border-neutral-300 transition-all cursor-pointer disabled:opacity-30 disabled:cursor-not-allowed`}
          title={`${t.reset} (R)`}
          id="btn-reset"
        >
          <RotateCcw size={18} className="transition-transform group-hover:-rotate-45" />
        </button>

        {/* Start / Pause Button (Main Accent) */}
        <button
          onClick={handleStartStop}
          className={`flex items-center justify-center px-8 py-3.5 rounded-full font-semibold font-display tracking-tight text-white shadow-md active:scale-[0.98] transition-all cursor-pointer ${
            isRunning 
              ? "bg-neutral-900 hover:bg-neutral-800 hover:shadow-lg hover:shadow-neutral-900/10" 
              : "bg-emerald-600 hover:bg-emerald-500 hover:shadow-lg hover:shadow-emerald-600/10"
          }`}
          id="btn-start-pause"
        >
          <span className="flex items-center gap-2">
            {isRunning ? <Pause size={18} fill="currentColor" /> : <Play size={18} fill="currentColor" />}
            {isRunning ? t.pause : time > 0 ? t.resume : t.start}
          </span>
        </button>

        {/* Lap Button */}
        <button
          onClick={handleLap}
          disabled={!isRunning}
          className={`group flex items-center justify-center w-12 h-12 rounded-full border border-neutral-200 bg-white text-neutral-500 hover:text-neutral-800 hover:bg-neutral-50 active:bg-neutral-100 hover:border-neutral-300 transition-all cursor-pointer disabled:opacity-30 disabled:cursor-not-allowed`}
          title={`${t.lap} (L)`}
          id="btn-lap"
        >
          <Flag size={18} className="transition-transform group-active:scale-95" />
        </button>
      </div>

      {/* Lap / Splits Analysis Section */}
      <div className="w-full bg-white rounded-2xl border border-neutral-200/80 p-4 shadow-xs" id="laps-card">
        <div className="flex items-center justify-between border-b border-neutral-100 pb-3 mb-3" id="laps-header">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-neutral-400"></span>
            <h3 className="font-display font-medium text-sm text-neutral-700" id="laps-title">{t.laps}</h3>
            {laps.length > 0 && (
              <span className="text-xs px-2 py-0.5 rounded-full bg-neutral-100 text-neutral-500 font-mono" id="laps-badge">
                {laps.length}
              </span>
            )}
          </div>
          {laps.length > 0 && (
            <button
              onClick={handleClearLapsOnDemand}
              className="flex items-center gap-1.5 text-xs text-neutral-400 hover:text-rose-500 active:scale-95 transition-colors cursor-pointer"
              title="Clear all laps"
              id="btn-clear-laps"
            >
              <Trash2 size={13} />
              {t.clearLaps}
            </button>
          )}
        </div>

        {/* List content wrapper */}
        {laps.length === 0 ? (
          <div className="py-8 text-center" id="laps-empty-state">
            <p className="text-xs text-neutral-400 italic font-sans px-4">
              {t.noLapsYet}
            </p>
          </div>
        ) : (
          <div className="flex flex-col" id="laps-populated-state">
            {/* Average block if multiples */}
            {laps.length >= 2 && (
              <div className="flex items-center justify-between bg-neutral-50 rounded-lg px-3 py-2 mb-3 text-xs text-neutral-500 font-mono" id="laps-average-summary">
                <span className="flex items-center gap-1.5">
                  <Award size={13} className="text-neutral-400" />
                  {t.average}
                </span>
                <span className="font-semibold text-neutral-700">{formatLapDuration(averageLapMs)}</span>
              </div>
            )}

            {/* Scrollable list of recorded items */}
            <div className="max-h-56 overflow-y-auto pr-1" id="laps-scroll-container">
              <table className="w-full text-left border-collapse" id="laps-table">
                <thead>
                  <tr className="text-[10px] uppercase tracking-wider text-neutral-400 font-display border-b border-neutral-50 pb-2">
                    <th className="py-1.5">Lap</th>
                    <th className="py-1.5 text-right">Lap Split</th>
                    <th className="py-1.5 text-right">Cumulative Time</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-neutral-50 font-mono text-sm">
                  {laps.map((lap) => {
                    const isNewFastest = lap.index === fastestLapId;
                    const isNewSlowest = lap.index === slowestLapId;

                    return (
                      <tr 
                        key={lap.index} 
                        className={`hover:bg-neutral-50 transition-colors ${
                          isNewFastest 
                            ? "text-emerald-700 bg-emerald-50/20" 
                            : isNewSlowest 
                              ? "text-rose-700 bg-rose-50/20" 
                              : "text-neutral-700"
                        }`}
                        id={`lap-row-${lap.index}`}
                      >
                        <td className="py-2.5 font-medium">
                          #{lap.index}
                        </td>
                        <td className="py-2.5 text-right font-medium">
                          <div className="flex items-center justify-end gap-1.5">
                            {formatLapDuration(lap.durationMs)}
                            {isNewFastest && (
                              <span className="text-[9px] font-sans font-bold px-1.5 py-0.5 rounded bg-emerald-100 text-emerald-800 uppercase tracking-wide">
                                {t.fastest.split(" ")[1] || "FAST"}
                              </span>
                            )}
                            {isNewSlowest && (
                              <span className="text-[9px] font-sans font-bold px-1.5 py-0.5 rounded bg-rose-100 text-rose-800 uppercase tracking-wide">
                                {t.slowest.split(" ")[1] || "SLOW"}
                              </span>
                            )}
                          </div>
                        </td>
                        <td className="py-2.5 text-right text-neutral-400">
                          {formatLapDuration(lap.absoluteMs)}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
