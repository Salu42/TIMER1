import { useState, useEffect, useRef } from "react";
import { Play, Pause, RotateCcw, Bell, BellOff, Hourglass } from "lucide-react";
import { playClickSound, playAlarmSound } from "../utils/audio";
import { LocalizedStrings } from "../utils/translations";

interface CountdownTimerProps {
  t: LocalizedStrings;
  soundEnabled: boolean;
}

export default function CountdownTimer({ t, soundEnabled }: CountdownTimerProps) {
  // Input fields state (when timer is not running/yet configured)
  const [inputHrs, setInputHrs] = useState(0);
  const [inputMins, setInputMins] = useState(5); // default to 5 minutes
  const [inputSecs, setInputSecs] = useState(0);

  // Active Timer state
  const [totalDurationSec, setTotalDurationSec] = useState(0);
  const [remainingSec, setRemainingSec] = useState(0);
  const [isActive, setIsActive] = useState(false);
  const [isFinished, setIsFinished] = useState(false);

  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const alarmIntervalRef = useRef<NodeJS.Timeout | null>(null);

  // Initialize from inputs
  const initializeTimer = () => {
    const total = inputHrs * 3600 + inputMins * 60 + inputSecs;
    if (total > 0) {
      setTotalDurationSec(total);
      setRemainingSec(total);
      setIsFinished(false);
      return true;
    }
    return false;
  };

  const handleStartStop = () => {
    if (soundEnabled) playClickSound(1000, 0.04);

    if (isActive) {
      // Pause
      setIsActive(false);
      if (timerRef.current) clearInterval(timerRef.current);
    } else {
      // Start/Resume
      if (isFinished) {
        // Clear finished state
        stopAlarm();
        setIsFinished(false);
      }

      // If progress is fresh, configure from inputs
      if (remainingSec === 0) {
        const ok = initializeTimer();
        if (!ok) return; // cannot start clean timer off 00:00:00
      }

      setIsActive(true);
    }
  };

  // The core timer interval
  useEffect(() => {
    if (isActive && remainingSec > 0) {
      timerRef.current = setInterval(() => {
        setRemainingSec((prev) => {
          if (prev <= 1) {
            handleTimerComplete();
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isActive, remainingSec]);

  const handleTimerComplete = () => {
    setIsActive(false);
    setIsFinished(true);
    if (timerRef.current) clearInterval(timerRef.current);

    // Trigger local audible alarm
    if (soundEnabled) {
      // play immediately
      playAlarmSound();
      // repeat every 2.5 seconds loop
      alarmIntervalRef.current = setInterval(() => {
        playAlarmSound();
      }, 2500);
    }
  };

  const stopAlarm = () => {
    if (alarmIntervalRef.current) {
      clearInterval(alarmIntervalRef.current);
      alarmIntervalRef.current = null;
    }
  };

  const handleReset = () => {
    if (soundEnabled) playClickSound(600, 0.06);
    setIsActive(false);
    stopAlarm();
    setIsFinished(false);
    setRemainingSec(0);
    setTotalDurationSec(0);
  };

  // Presets trigger helper
  const applyPreset = (minutesToAdd: number) => {
    if (soundEnabled) playClickSound(1100, 0.04);
    
    // Stop running cycles
    setIsActive(false);
    stopAlarm();
    setIsFinished(false);

    // Calculate new count
    const targetSec = minutesToAdd * 60;
    setTotalDurationSec(targetSec);
    setRemainingSec(targetSec);

    // Also populate fields so layout reflects it
    const hrs = Math.floor(minutesToAdd / 60);
    const mins = minutesToAdd % 60;
    setInputHrs(hrs);
    setInputMins(mins);
    setInputSecs(0);
  };

  // Stop alarm on unmount
  useEffect(() => {
    return () => {
      stopAlarm();
    };
  }, []);

  // Format Helper
  const formatSeconds = (total: number) => {
    const hrs = Math.floor(total / 3600);
    const mins = Math.floor((total % 3600) / 60);
    const secs = total % 60;

    const pad = (n: number) => n.toString().padStart(2, "0");
    return {
      hours: pad(hrs),
      minutes: pad(mins),
      seconds: pad(secs),
    };
  };

  const displayTime = formatSeconds(remainingSec === 0 && !isFinished ? (inputHrs * 3600 + inputMins * 60 + inputSecs) : remainingSec);

  // Compute SVG Stroke Offset
  const radius = 94;
  const circumference = 2 * Math.PI * radius;
  // If fresh/finished/totalDurationSec is 0, percentage is 100% full
  const ratio = totalDurationSec > 0 ? remainingSec / totalDurationSec : 1;
  const strokeDashoffset = circumference - ratio * circumference;

  return (
    <div className="flex flex-col items-center justify-center p-2 sm:p-4 w-full max-w-xl mx-auto" id="timer-container">
      {/* Visual Circle Progress ring */}
      <div 
        className={`relative flex items-center justify-center w-64 h-64 sm:w-72 sm:h-72 rounded-full border border-neutral-200/80 bg-white shadow-xs mb-8 transition-colors ${
          isFinished ? "bg-rose-50 border-rose-200 animate-pulse" : ""
        }`}
        id="timer-ring-outer"
      >
        {/* SVG Circle Graphic */}
        <svg className="absolute w-full h-full -rotate-90 transform p-4" id="progress-svg">
          {/* Track Circle */}
          <circle
            cx="50%"
            cy="50%"
            r={radius}
            className="stroke-neutral-100 fill-transparent"
            strokeWidth="6"
            id="track-circle"
          />
          {/* Progress Active Accent Circle */}
          <circle
            cx="50%"
            cy="50%"
            r={radius}
            className={`fill-transparent transition-all duration-300 ease-out ${
              isFinished 
                ? "stroke-rose-500" 
                : isActive 
                  ? "stroke-neutral-800" 
                  : "stroke-neutral-400"
            }`}
            strokeWidth="6"
            strokeDasharray={circumference}
            strokeDashoffset={strokeDashoffset}
            strokeLinecap="round"
            id="animated-progress-circle"
          />
        </svg>

        {/* Central Counter Display */}
        <div className="z-10 flex flex-col items-center justify-center text-center" id="countdown-dial-content">
          <span className="text-xs uppercase tracking-widest text-neutral-400 font-display font-semibold mb-1" id="timer-label">
            {t.timer}
          </span>

          {isFinished ? (
            <div className="flex flex-col items-center text-rose-600 animate-bounce" id="alarm-ring-state">
              <span className="text-xl sm:text-2xl font-display font-bold mb-1" id="finished-headline">
                {t.timerFinished}
              </span>
              <button 
                onClick={handleReset}
                className="text-xs px-3 py-1 flex items-center gap-1.5 rounded-full bg-rose-100 font-medium text-rose-700 hover:bg-rose-200 border border-rose-300 transition-all cursor-pointer"
                id="btn-silence-alarm"
              >
                <BellOff size={12} />
                STOP
              </button>
            </div>
          ) : (
            <div className="flex flex-col items-center" id="normal-tick-interface">
              {/* Massive Tabular Numbers */}
              <div className="flex items-center justify-center font-mono text-neutral-800 text-4xl sm:text-5xl font-bold tracking-tight" id="countdown-numbers">
                <span>{displayTime.hours}</span>
                <span className="mx-1 text-neutral-300 text-3xl font-light">:</span>
                <span>{displayTime.minutes}</span>
                <span className="mx-1 text-neutral-300 text-3xl font-light">:</span>
                <span>{displayTime.seconds}</span>
              </div>

              {/* Helper detail showing target full duration */}
              {totalDurationSec > 0 && remainingSec > 0 && (
                <span className="text-[10px] text-neutral-400 font-mono mt-1" id="percentage-indicator">
                  {Math.round(ratio * 100)}% left of {formatSeconds(totalDurationSec).hours}:{formatSeconds(totalDurationSec).minutes}:{formatSeconds(totalDurationSec).seconds}
                </span>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Manual Picker Controllers (Shown only if timer is inactive and clean) */}
      {!isActive && remainingSec === 0 && !isFinished && (
        <div className="w-full bg-white border border-neutral-200/60 rounded-2xl p-4 mb-6 shadow-xs animate-fade-in" id="manual-picker-panel">
          <span className="block text-xs font-display font-medium text-neutral-500 mb-3 text-center" id="picker-title">
            {t.setCountdown}
          </span>
          <div className="flex items-center justify-center gap-6" id="picker-selectors">
            {/* Hours Picker */}
            <div className="flex flex-col items-center">
              <label className="text-[10px] uppercase font-display text-neutral-400 mb-1 font-semibold">{t.hours}</label>
              <select
                value={inputHrs}
                onChange={(e) => {
                  if (soundEnabled) playClickSound(1400, 0.02);
                  setInputHrs(Math.max(0, parseInt(e.target.value) || 0));
                }}
                className="font-mono text-sm px-2.5 py-1.5 rounded-lg border border-neutral-200 bg-neutral-50 text-neutral-700 focus:outline-hidden focus:border-neutral-400"
                id="select-hours"
              >
                {Array.from({ length: 24 }).map((_, i) => (
                  <option key={i} value={i}>{i.toString().padStart(2, "0")}</option>
                ))}
              </select>
            </div>

            {/* Separator */}
            <span className="text-neutral-300 font-mono text-xl self-end mb-1">:</span>

            {/* Minutes Picker */}
            <div className="flex flex-col items-center">
              <label className="text-[10px] uppercase font-display text-neutral-400 mb-1 font-semibold">{t.minutes}</label>
              <select
                value={inputMins}
                onChange={(e) => {
                  if (soundEnabled) playClickSound(1400, 0.02);
                  setInputMins(Math.max(0, parseInt(e.target.value) || 0));
                }}
                className="font-mono text-sm px-2.5 py-1.5 rounded-lg border border-neutral-200 bg-neutral-50 text-neutral-700 focus:outline-hidden focus:border-neutral-400"
                id="select-minutes"
              >
                {Array.from({ length: 60 }).map((_, i) => (
                  <option key={i} value={i}>{i.toString().padStart(2, "0")}</option>
                ))}
              </select>
            </div>

            {/* Separator */}
            <span className="text-neutral-300 font-mono text-xl self-end mb-1">:</span>

            {/* Seconds Picker */}
            <div className="flex flex-col items-center">
              <label className="text-[10px] uppercase font-display text-neutral-400 mb-1 font-semibold">{t.seconds}</label>
              <select
                value={inputSecs}
                onChange={(e) => {
                  if (soundEnabled) playClickSound(1400, 0.02);
                  setInputSecs(Math.max(0, parseInt(e.target.value) || 0));
                }}
                className="font-mono text-sm px-2.5 py-1.5 rounded-lg border border-neutral-200 bg-neutral-50 text-neutral-700 focus:outline-hidden focus:border-neutral-400"
                id="select-seconds"
              >
                {Array.from({ length: 60 }).map((_, i) => (
                  <option key={i} value={i}>{i.toString().padStart(2, "0")}</option>
                ))}
              </select>
            </div>
          </div>
        </div>
      )}

      {/* Preset Fast Quick buttons (Enabled only when inactive) */}
      <div className="w-full mb-8" id="quick-presets-section">
        <label className="block text-center text-[10px] uppercase tracking-wider font-display font-semibold text-neutral-400 mb-2">
          {t.presets}
        </label>
        <div className="flex flex-wrap items-center justify-center gap-2" id="presets-button-grid">
          <button
            onClick={() => applyPreset(1)}
            disabled={isActive}
            className="px-3 py-1.5 rounded-full border border-neutral-200 text-xs font-mono font-medium bg-white text-neutral-600 hover:bg-neutral-50 hover:border-neutral-300 active:bg-neutral-100 disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer transition-all"
            id="preset-1m"
          >
            +1 Min
          </button>
          <button
            onClick={() => applyPreset(5)}
            disabled={isActive}
            className="px-3 py-1.5 rounded-full border border-neutral-200 text-xs font-mono font-medium bg-white text-neutral-600 hover:bg-neutral-50 hover:border-neutral-300 active:bg-neutral-100 disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer transition-all"
            id="preset-5m"
          >
            +5 Min
          </button>
          <button
            onClick={() => applyPreset(10)}
            disabled={isActive}
            className="px-3 py-1.5 rounded-full border border-neutral-200 text-xs font-mono font-medium bg-white text-neutral-600 hover:bg-neutral-50 hover:border-neutral-300 active:bg-neutral-100 disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer transition-all"
            id="preset-10m"
          >
            +10 Min
          </button>
          <button
            onClick={() => applyPreset(25)}
            disabled={isActive}
            className="px-3 py-1.5 rounded-full border border-neutral-200 text-xs font-mono font-medium bg-white text-neutral-600 hover:bg-neutral-50 hover:border-neutral-300 active:bg-neutral-100 disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer transition-all"
            id="preset-25m"
          >
            +25 Min (Pomodoro)
          </button>
        </div>
      </div>

      {/* Main Core Stop/Start Action Bars */}
      <div className="flex items-center justify-center gap-4 w-full" id="timer-action-dock">
        {/* Reset / Force Reset */}
        <button
          onClick={handleReset}
          disabled={remainingSec === 0 && !isFinished}
          className="group flex items-center justify-center w-12 h-12 rounded-full border border-neutral-200 bg-white text-neutral-500 hover:text-neutral-800 hover:bg-neutral-50 active:bg-neutral-100 hover:border-neutral-300 transition-all cursor-pointer disabled:opacity-30 disabled:cursor-not-allowed"
          title={t.reset}
          id="btn-timer-reset"
        >
          <RotateCcw size={18} className="transition-transform group-hover:-rotate-45" />
        </button>

        {/* Start / Pause */}
        <button
          onClick={handleStartStop}
          className={`flex items-center justify-center px-8 py-3.5 rounded-full font-semibold font-display tracking-tight text-white shadow-md active:scale-[0.98] transition-all cursor-pointer ${
            isActive 
              ? "bg-neutral-900 hover:bg-neutral-800 hover:shadow-lg hover:shadow-neutral-900/10" 
              : "bg-teal-600 hover:bg-teal-500 hover:shadow-lg hover:shadow-teal-600/10"
          }`}
          id="btn-timer-start-pause"
        >
          <span className="flex items-center gap-2">
            {isActive ? <Pause size={18} fill="currentColor" /> : <Play size={18} fill="currentColor" />}
            {isActive ? t.pause : remainingSec > 0 ? t.resume : t.start}
          </span>
        </button>

        {/* Informative Status Badge for alignment */}
        <div className="flex items-center justify-center w-12 h-12 rounded-full border border-neutral-200 bg-neutral-50 text-neutral-400" id="hourglass-decorative-hud">
          <Hourglass size={18} className={`${isActive ? "animate-spin" : ""}`} />
        </div>
      </div>
    </div>
  );
}
