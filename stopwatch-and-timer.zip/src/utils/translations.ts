export interface LocalizedStrings {
  title: string;
  subtitle: string;
  stopwatch: string;
  timer: string;
  start: string;
  pause: string;
  resume: string;
  stop: string;
  lap: string;
  reset: string;
  laps: string;
  fastest: string;
  slowest: string;
  average: string;
  noLapsYet: string;
  presets: string;
  setCountdown: string;
  hours: string;
  minutes: string;
  seconds: string;
  currentProgress: string;
  timerFinished: string;
  soundOn: string;
  soundOff: string;
  keyboardShortcuts: string;
  spaceShortcut: string;
  lapShortcut: string;
  resetShortcut: string;
  clearLaps: string;
}

export const translations: Record<"en" | "hi", LocalizedStrings> = {
  en: {
    title: "ChronoPrecision",
    subtitle: "High precision tactical stopwatch and dynamic visual countdown timer.",
    stopwatch: "Stopwatch",
    timer: "Timer",
    start: "Start",
    pause: "Pause",
    resume: "Resume",
    stop: "Stop",
    lap: "Lap",
    reset: "Reset",
    laps: "Recorded Laps",
    fastest: "⚡ Fastest",
    slowest: "⏳ Slowest",
    average: "Ø Average",
    noLapsYet: "No laps recorded yet. Press the Lap button while running.",
    presets: "Timer Presets",
    setCountdown: "Set Countdown Duration",
    hours: "Hours",
    minutes: "Minutes",
    seconds: "Seconds",
    currentProgress: "Progress",
    timerFinished: "Timer Completed!",
    soundOn: "Sound On",
    soundOff: "Mute",
    keyboardShortcuts: "Keyboard Shortcuts",
    spaceShortcut: "Space : Start / Pause",
    lapShortcut: "L : Record Lap",
    resetShortcut: "R : Reset Counter",
    clearLaps: "Clear All",
  },
  hi: {
    title: "क्रोनोप्रिसिजन (Stopwatch)",
    subtitle: "उच्च स्तर की टाइम-ट्रैकिंग और सुंदर काउंटडाउन विज़ुअल टाइमर।",
    stopwatch: "स्टॉपवॉच (स्टार्ट-स्टॉप)",
    timer: "टाइमर (उल्टी गिनती)",
    start: "शुरू करें (Start)",
    pause: "रोकें (Pause)",
    resume: "जारी रखें (Resume)",
    stop: "बंद करें (Stop)",
    lap: "लैप दर्ज करें (Lap)",
    reset: "रीसेट (Reset)",
    laps: "रिकॉर्ड किए गए लैप्स",
    fastest: "⚡ सबसे तेज़",
    slowest: "⏳ सबसे धीमा",
    average: "Ø औसत समय",
    noLapsYet: "कोई लैप रिकॉर्ड नहीं किया गया। चालू होने पर 'Lap' दबाएं।",
    presets: "त्वरित टाइमर",
    setCountdown: "काउंटडाउन का समय चुनें",
    hours: "घंटे",
    minutes: "मिनट",
    seconds: "सेकंड",
    currentProgress: "प्रगति",
    timerFinished: "समय समाप्त हो गया है!",
    soundOn: "आवाज चालू",
    soundOff: "म्यूट",
    keyboardShortcuts: "कुंजीपटल शॉर्टकट",
    spaceShortcut: "Space : शुरू / रोकें",
    lapShortcut: "L : लैप रिकॉर्ड करें",
    resetShortcut: "R : रीसेट करें",
    clearLaps: "साफ़ करें",
  },
};
