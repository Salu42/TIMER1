/**
 * Web Audio Synthesizer for tactile feedback
 */

let audioCtx: AudioContext | null = null;

function getAudioContext(): AudioContext | null {
  if (typeof window === "undefined") return null;
  if (!audioCtx) {
    const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
    if (AudioContextClass) {
      audioCtx = new AudioContextClass();
    }
  }
  return audioCtx;
}

/**
 * Play a high-quality physical mechanical button click click audio-cue
 */
export function playClickSound(frequency = 1000, duration = 0.05) {
  try {
    const ctx = getAudioContext();
    if (!ctx || ctx.state === "suspended") return;

    const osc = ctx.createOscillator();
    const gainNode = ctx.createGain();

    osc.type = "sine";
    osc.frequency.setValueAtTime(frequency, ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(frequency / 2, ctx.currentTime + duration);

    gainNode.gain.setValueAtTime(0.15, ctx.currentTime);
    gainNode.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + duration);

    osc.connect(gainNode);
    gainNode.connect(ctx.destination);

    osc.start();
    osc.stop(ctx.currentTime + duration);
  } catch (error) {
    console.warn("Audio feedback error:", error);
  }
}

/**
 * Play an alarm signal (double pulse) when the countdown finishes
 */
export function playAlarmSound() {
  try {
    const ctx = getAudioContext();
    if (!ctx || ctx.state === "suspended") return;

    const now = ctx.currentTime;
    
    // Create two discrete alarm beeps in succession
    [0, 0.25, 0.5, 0.75].forEach((delay) => {
      const osc = ctx.createOscillator();
      const gainNode = ctx.createGain();

      osc.type = "triangle";
      osc.frequency.setValueAtTime(880, now + delay);
      
      gainNode.gain.setValueAtTime(0, now + delay);
      gainNode.gain.linearRampToValueAtTime(0.2, now + delay + 0.02);
      gainNode.gain.linearRampToValueAtTime(0.2, now + delay + 0.12);
      gainNode.gain.exponentialRampToValueAtTime(0.001, now + delay + 0.15);

      osc.connect(gainNode);
      gainNode.connect(ctx.destination);

      osc.start(now + delay);
      osc.stop(now + delay + 0.16);
    });
  } catch (error) {
    console.warn("Alarm audio error:", error);
  }
}

/**
 * Initialize Audio Context on first user speech/interaction
 */
export function initializeAudio() {
  try {
    const ctx = getAudioContext();
    if (ctx && ctx.state === "suspended") {
      ctx.resume();
    }
  } catch (err) {
    // Ignore error silently
  }
}
